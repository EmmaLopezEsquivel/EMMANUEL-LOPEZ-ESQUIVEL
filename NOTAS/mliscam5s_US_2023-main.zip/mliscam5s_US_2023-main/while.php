<?php

    $repeticiones = 5;

    while($a <= $repeticiones){
        echo " a vale {$a}\n";
        $a++;
    }
?>